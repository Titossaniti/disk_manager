export default function RedirectRoot() {
    return null;
}